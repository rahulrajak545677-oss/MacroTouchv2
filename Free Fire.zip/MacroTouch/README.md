# Free Fire (Android)

AssistiveTouch-style floating button + gesture recorder/player for Android.

## Build the APK (no PC needed)
1. Create a GitHub repo, upload this whole folder (keep `.github/workflows/build.yml`).
2. Repo → Actions → "Build APK" → Run workflow.
3. Download artifact `MacroTouch-APK`, unzip, install `app-debug.apk`.

(Or open the folder in Android Studio → Run.)

## First run
1. Open Free Fire → switch **AssistiveTouch** on → enable the accessibility service "Free Fire".
   Android 13+: Settings → Apps → Free Fire → ⋮ → *Allow restricted settings*, then enable it.
2. A floating button appears. Tap it → **Custom → +** (or "Create New Gesture…" in the app).
3. Tap/swipe (multi-finger OK) → **Save** → type a name.
4. Go to your game/app → tap button → Custom → your gesture. Tap the button again to stop. Repeat count/delay: app → Playback.

## Playback engine (v2)
- Touches that overlap in time are sent as one multi-finger gesture; actions run one after another.
- Actions longer than 600 ms are sent in 200 ms pieces (willContinue/continueStroke), so Stop/Pause work between pieces.
- Red circles are drawn from the strokes actually handed to `dispatchGesture()`.
- While a macro runs: **tap the button = stop**, **long-press = pause/resume** (pause happens between actions).
- Per-macro speed, repeat and delay: Custom Gestures → tap a macro.
- Limits: max simultaneous touches = `GestureDescription.getMaxStrokeCount()` (device dependent); a physical touch cancels the injected gesture; macros recorded in portrait won't play in landscape (and vice versa); apps may ignore injected touches (e.g. secure screens, some anti-cheat).

## Device test checklist (not yet run on hardware)
1. Service enable flow incl. Android 13+ "Allow restricted settings".
2. Gestures menu: Long Press, Double Tap, Hold and Drag, Pinch In/Out, Rotate, Pinch and Rotate, Swipe ×4 — circles appear where the touch lands, move, vanish.
3. Record a 2–3 finger macro → Save → Play; compare with the recording.
4. Tap button mid-macro → fingers lift within ~0.6 s; no stuck touch.
5. Long-press button mid-macro → pauses after current action; long-press again resumes.
6. Rotate the phone: button stays on screen; mismatched-orientation macro shows a message.
7. Rename/delete a macro assigned to Single-Tap: button still opens the menu.

## Touch Buttons (collapse / expand)
- App → Playback → **Touch Buttons: On**. One red button per saved gesture appears (tap = play, drag = move the button only).
- **Double-tap the floating icon** (Custom Actions → Double-Tap → "Collapse / Expand Buttons", the default if unset) → all buttons fold into ONE red ring that stays put and passes touches through. Double-tap again → buttons return to their spots.
- Overlay positions (`ButtonLayer`, keys `bp_*` / `ic_*`) are fully separate from gesture coordinates (`Macro.strokes`, played by `Player`). Moving or collapsing buttons never edits a macro; playing a macro never moves a button.
- Known limit: while a macro is running, the first tap on the floating icon stops it, so a double-tap during playback stops the macro instead of toggling.

## Diagnosing missing overlays
- App → Playback → **Touch Buttons** row shows live status (e.g. "2 shown", "none — no saved gestures", "addView failed: …").
- App → Playback → **Overlay log** shows / copies the last 150 lines. Same lines go to Logcat, tag `FFMacro`.
- Logged: service connect (SDK, overlay type), every addView (type, flags, x/y, size) or its exception, button positions, orientation mismatches, and a check of every overlay each time another app (e.g. Free Fire MAX) comes to the front.

## Collapsed ring = swipe assist (like iPhone Custom Gestures)
After the double-tap collapse, the red ring stays fixed. Swipe on it and lift your finger: the app reads the direction of your swipe, picks the saved gesture whose main swipe points the same way (within ~45°; ties go to the one recorded nearest the ring) and plays it exactly as saved, once. A plain tap on the ring is passed to the game at the ring's position. Your real touch on the ring is consumed (the game only receives the saved gesture), so holding fire on the ring is not supported while collapsed. Logged under tag `FFMacro` ("assist: …").
