package com.macrotouch

import android.util.Log
import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale

/** Logcat tag "FFMacro" + an in-app ring buffer (App > Playback > Overlay log) so no adb is needed. */
object Diag {
    const val TAG = "FFMacro"
    private val buf = ArrayDeque<String>()
    private val fmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    @Synchronized private fun add(level: String, m: String) {
        buf.addLast("${fmt.format(Date())} $level $m")
        while (buf.size > 150) buf.removeFirst()
    }
    fun i(m: String) { Log.i(TAG, m); add("I", m) }
    fun w(m: String) { Log.w(TAG, m); add("W", m) }
    fun e(m: String, t: Throwable? = null) {
        Log.e(TAG, m, t); add("E", if (t != null) "$m — ${t.javaClass.simpleName}: ${t.message}" else m)
    }
    @Synchronized fun dump(): String = if (buf.isEmpty()) "(no log yet)" else buf.joinToString("\n")
    @Synchronized fun clear() { buf.clear() }
}
