package com.macrotouch

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*

/** Settings screen styled like iOS Settings > Accessibility > Touch > AssistiveTouch. */
class MainActivity : Activity() {
    private val CARD = 0xFF1C1C1E.toInt()
    private val BLUE = 0xFF0A84FF.toInt()
    private val GREY = 0xFF8E8E93.toInt()
    private val RED = 0xFFFF453A.toInt()
    private var editMode = false
    private var keepY = 0
    private var sv: ScrollView? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        render()
    }
    private fun showOverlayLog() {
        val tvLog = TextView(this).apply {
            text = Diag.dump(); textSize = 11f; typeface = Typeface.MONOSPACE; setTextColor(Color.WHITE); setPadding(dp(16), dp(8), dp(16), dp(8))
        }
        AlertDialog.Builder(this).setTitle("Overlay log (also in Logcat, tag FFMacro)")
            .setView(ScrollView(this).apply { addView(tvLog) })
            .setPositiveButton("Close", null)
            .setNeutralButton("Copy") { _, _ ->
                (getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager)
                    .setPrimaryClip(android.content.ClipData.newPlainText("FFMacro log", Diag.dump()))
                Toast.makeText(this, "Log copied", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Clear") { _, _ -> Diag.clear() }
            .show()
    }

    private val REQ_OVERLAY = 4711

    /** Opens Settings > Display over other apps for this package. Never crashes if the screen is missing. */
    private fun requestOverlayPermission() {
        if (Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "“Display over other apps” is already allowed", Toast.LENGTH_SHORT).show(); return
        }
        try {
            @Suppress("DEPRECATION")
            startActivityForResult(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")), REQ_OVERLAY)
        } catch (e: ActivityNotFoundException) {
            try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }
            catch (e2: Exception) { Toast.makeText(this, "Open Settings → Apps → Free Fire → Display over other apps", Toast.LENGTH_LONG).show() }
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_OVERLAY) {
            // The settings screen returns RESULT_CANCELED either way; the real answer is canDrawOverlays().
            Toast.makeText(this, if (Settings.canDrawOverlays(this)) "Display over other apps: allowed" else "Display over other apps: not allowed (optional — the floating button still works)", Toast.LENGTH_LONG).show()
            render()
        }
    }

    override fun onResume() { super.onResume(); render(); TouchService.inst?.refreshButtons() }
    override fun onPause() { super.onPause(); TouchService.inst?.refreshButtons() }

    private fun tv(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun header(s: String) = tv(s.uppercase(), 12.5f, GREY).apply { setPadding(dp(16), dp(22), dp(16), dp(6)) }
    private fun footer(s: String) = tv(s, 12.5f, GREY).apply { setPadding(dp(16), dp(6), dp(16), 0) }

    private fun row(title: String, value: String? = null, color: Int = Color.WHITE, click: (() -> Unit)? = null): LinearLayout {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        r.addView(tv(title, 16f, color), LinearLayout.LayoutParams(0, -2, 1f))
        if (value != null) r.addView(tv(value, 16f, GREY))
        if (click != null) { r.addView(tv("  ›", 18f, GREY)); r.setOnClickListener { click() } }
        return r
    }

    private fun card(rows: List<View>): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply { setColor(CARD); cornerRadius = dp(12).toFloat() }
        }
        rows.forEachIndexed { i, v ->
            if (i > 0) c.addView(View(this).apply { setBackgroundColor(0xFF38383A.toInt()) },
                LinearLayout.LayoutParams(-1, 1).apply { marginStart = dp(16) })
            c.addView(v)
        }
        return c
    }

    private fun actionLabel(a: String) = when {
        a == "none" -> "None"
        a == "menu" -> "Open Menu"
        a == "toggle" -> "Collapse / Expand Buttons"
        a.startsWith("m:") -> a.substring(2)
        else -> "None"
    }

    private fun render() {
        sv?.let { keepY = it.scrollY }
        val macros = Store.load(this)
        val running = TouchService.inst != null
        val enabled = Store.getBool(this, "enabled", false)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(34), dp(14), dp(50))
        }

        // Title bar: AssistiveTouch ........ Edit/Done
        val bar = FrameLayout(this)
        bar.addView(tv("AssistiveTouch", 17f, Color.WHITE, true), FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        bar.addView(tv(if (editMode) "Done" else "Edit", 17f, BLUE).apply {
            setPadding(dp(10), dp(10), dp(4), dp(10))
            setOnClickListener { editMode = !editMode; render() }
        }, FrameLayout.LayoutParams(-2, -2, Gravity.END or Gravity.CENTER_VERTICAL))
        col.addView(bar)

        // Master switch
        val sw = Switch(this).apply { isChecked = enabled }
        val swRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(10), dp(16), dp(10))
        }
        swRow.addView(tv("AssistiveTouch", 16f, Color.WHITE), LinearLayout.LayoutParams(0, -2, 1f))
        swRow.addView(sw)
        sw.setOnCheckedChangeListener { _, on ->
            Store.putBool(this, "enabled", on)
            val s = TouchService.inst
            if (on && s == null) {
                AlertDialog.Builder(this).setTitle("Allow the accessibility service")
                    .setMessage("Open Accessibility settings → Installed apps → “Free Fire” → turn it ON.\n\nAndroid 13+: if the switch is greyed out, go to Settings → Apps → FF → ⋮ → “Allow restricted settings”, then try again.")
                    .setPositiveButton("Open settings") { _, _ -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                    .setNegativeButton("Later", null).show()
            } else if (on) s?.showButton() else s?.hideButton()
        }
        col.addView(card(listOf(swRow)), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(18) })
        col.addView(footer(
            "AssistiveTouch shows a floating button on any screen. Tap it to open the menu (Custom, Gestures, Device, Home, Control Center). " +
            "Record your own multi-touch gestures, save them, and replay them in any app or game."))

        // Service status
        col.addView(header("Setup"))
        col.addView(card(listOf(
            row("Accessibility service", if (running) "Running ✓" else "Not enabled", if (running) Color.WHITE else RED) {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            },
            row("Display over other apps", if (Settings.canDrawOverlays(this)) "Allowed ✓" else "Tap to allow") {
                requestOverlayPermission()
            })))

        // Custom actions
        col.addView(header("Custom Actions"))
        col.addView(card(listOf(
            row("Single-Tap", actionLabel(Store.getStr(this, "a_single", "menu"))) { pickAction("a_single", "Single-Tap") },
            row("Double-Tap", actionLabel(Store.getStr(this, "a_double", "toggle"))) { pickAction("a_double", "Double-Tap") },
            row("Long Press", actionLabel(Store.getStr(this, "a_long", "none"))) { pickAction("a_long", "Long Press") }
        )))
        col.addView(footer("Custom actions allow you to interact directly with the AssistiveTouch icon without opening the menu. While a gesture is playing, tapping the icon stops it."))

        // Custom gestures
        col.addView(header("Custom Gestures"))
        val rows = mutableListOf<View>()
        macros.forEachIndexed { i, m ->
            if (!editMode) rows.add(row(m.name) { macroDialog(m) }) else {
                val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(8), dp(12), dp(8)) }
                r.addView(tv("⊖", 22f, RED).apply {
                    setPadding(dp(6), dp(6), dp(10), dp(6))
                    setOnClickListener {
                        AlertDialog.Builder(this@MainActivity).setTitle("Delete “${m.name}”?")
                            .setPositiveButton("Delete") { _, _ -> val l = Store.load(this@MainActivity); l.removeAll { it.name == m.name }; Store.save(this@MainActivity, l); Store.fixRefs(this@MainActivity, m.name, null); render() }
                            .setNegativeButton("Cancel", null).show()
                    }
                })
                r.addView(tv(m.name, 16f, Color.WHITE), LinearLayout.LayoutParams(0, -2, 1f))
                r.addView(tv("▲", 18f, GREY).apply { setPadding(dp(12), dp(8), dp(12), dp(8)); setOnClickListener { move(i, -1) } })
                r.addView(tv("▼", 18f, GREY).apply { setPadding(dp(12), dp(8), dp(6), dp(8)); setOnClickListener { move(i, 1) } })
                rows.add(r)
            }
        }
        rows.add(row("Create New Gesture…", null, if (editMode) GREY else Color.WHITE, if (editMode) null else ({ createGesture() })).also {
            if (!editMode) it.addView(tv("›", 18f, GREY))
        })
        col.addView(card(rows))
        col.addView(footer("Custom gestures allow you to record gestures that can be activated from Custom in the Menu. Tap a saved gesture to play it, rename it, change its speed / repeat / delay, or delete it."))

        // Idle opacity
        col.addView(card(listOf(row("Idle Opacity", "${Store.getInt(this, "opacity", 37)}%") { opacityDialog() })), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(22) })

        // Repeat
        col.addView(header("Playback"))
        val loops = Store.getInt(this, "loops", 0)
        col.addView(card(listOf(
            row("Repeat", if (loops == 0) "Forever" else "$loops×") { numberDialog("Repeat count (0 = forever)", "loops", 0) },
            row("Delay Between Repeats", "${Store.getInt(this, "gap", 0)} ms") { numberDialog("Delay between repeats (ms)", "gap", 0) }
        )))
        col.addView(card(listOf(
            row("Touch Buttons", TouchService.inst?.buttonStatus() ?: if (Store.getBool(this, "buttons_on", false)) "On" else "Off") {
                Store.putBool(this, "buttons_on", !Store.getBool(this, "buttons_on", false))
                TouchService.inst?.refreshButtons(); render()
            },
            row("Overlay log", "View") { showOverlayLog() })), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })
        col.addView(footer("Touch Buttons shows one red button per saved gesture (tap = play, drag = move the button only; the gesture itself never changes). Double-tap the floating icon to collapse them into one red ring that stays put and passes touches through; double-tap again to restore them. Playback shows red touch circles where the gesture is being performed."))

        val s = ScrollView(this).apply { setBackgroundColor(Color.BLACK); addView(col) }
        sv = s
        setContentView(s)
        s.post { s.scrollTo(0, keepY) }
    }

    private fun move(i: Int, d: Int) {
        val l = Store.load(this); val j = i + d
        if (j < 0 || j >= l.size) return
        val t = l[i]; l[i] = l[j]; l[j] = t
        Store.save(this, l); render()
    }

    private fun createGesture() {
        val s = TouchService.inst
        if (s == null) {
            Toast.makeText(this, "Enable the Free Fire accessibility service first", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        } else s.startRecorder()
    }

    private fun pickAction(key: String, title: String) {
        val macros = Store.load(this)
        val labels = mutableListOf("None", "Open Menu", "Collapse / Expand Buttons") + macros.map { it.name }
        val values = mutableListOf("none", "menu", "toggle") + macros.map { "m:" + it.name }
        val cur = values.indexOf(Store.getStr(this, key, if (key == "a_single") "menu" else if (key == "a_double") "toggle" else "none")).coerceAtLeast(0)
        AlertDialog.Builder(this).setTitle(title)
            .setSingleChoiceItems(labels.toTypedArray(), cur) { d, which -> Store.putStr(this, key, values[which]); d.dismiss(); render() }
            .show()
    }

    private fun updateMacro(name: String, f: (Macro) -> Macro) {
        val l = Store.load(this); val i = l.indexOfFirst { it.name == name }
        if (i >= 0) { l[i] = f(l[i]); Store.save(this, l); render() }
    }

    /** Number dialog for a per-macro setting. [allowDefault] adds "Use default" (stores -1 = global setting). */
    private fun macroSetting(m: Macro, title: String, cur: Int, range: IntRange, allowDefault: Boolean, change: (Macro, Int) -> Macro) {
        val et = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER; hint = "default"
            setText(if (cur >= 0) cur.toString() else ""); setSelectAllOnFocus(true)
        }
        val box = FrameLayout(this).apply { setPadding(dp(24), dp(12), dp(24), 0); addView(et) }
        val b = AlertDialog.Builder(this).setTitle(title).setView(box)
            .setPositiveButton("Done") { _, _ ->
                val v = et.text.toString().toIntOrNull()
                if (v != null) updateMacro(m.name) { change(it, v.coerceIn(range.first, range.last)) }
            }
            .setNegativeButton("Cancel", null)
        if (allowDefault) b.setNeutralButton("Use default") { _, _ -> updateMacro(m.name) { change(it, -1) } }
        b.show()
    }

    private fun macroDialog(m: Macro) {
        val loopsTxt = if (m.loops < 0) "default" else if (m.loops == 0) "forever" else "${m.loops}×"
        val gapTxt = if (m.gap < 0) "default" else "${m.gap} ms"
        AlertDialog.Builder(this).setTitle(m.name)
            .setItems(arrayOf("Play", "Rename", "Speed: ${m.speed}%", "Repeat: $loopsTxt", "Delay between repeats: $gapTxt", "Delete")) { _, w ->
                when (w) {
                    0 -> {
                        val s = TouchService.inst
                        if (s == null) Toast.makeText(this, "Enable the accessibility service first", Toast.LENGTH_LONG).show()
                        else { Toast.makeText(this, "Playing in 3 seconds — switch to your app", Toast.LENGTH_SHORT).show(); window.decorView.postDelayed({ s.play(m) }, 3000) }
                    }
                    1 -> {
                        val et = EditText(this).apply { setText(m.name); setTextColor(Color.WHITE); setSelectAllOnFocus(true) }
                        AlertDialog.Builder(this).setTitle("Rename").setView(et)
                            .setPositiveButton("Save") { _, _ ->
                                val n = et.text.toString().trim()
                                val l = Store.load(this)
                                if (n.isNotEmpty() && n != m.name && l.none { it.name == n }) {
                                    updateMacro(m.name) { it.copy(name = n) }
                                    Store.fixRefs(this, m.name, n)
                                    render()
                                } else if (n != m.name && n.isNotEmpty()) Toast.makeText(this, "That name is already used", Toast.LENGTH_SHORT).show()
                            }.setNegativeButton("Cancel", null).show()
                    }
                    2 -> macroSetting(m, "Speed % (100 = as recorded)", m.speed, 25..400, false) { mm, v -> mm.copy(speed = v) }
                    3 -> macroSetting(m, "Repeat count (0 = forever)", m.loops, 0..100000, true) { mm, v -> mm.copy(loops = v) }
                    4 -> macroSetting(m, "Delay between repeats (ms)", m.gap, 0..100000, true) { mm, v -> mm.copy(gap = v) }
                    5 -> { val l = Store.load(this); l.removeAll { it.name == m.name }; Store.save(this, l); Store.fixRefs(this, m.name, null); render() }
                }
            }.show()
    }

    private fun opacityDialog() {
        val cur = Store.getInt(this, "opacity", 37)
        val label = TextView(this).apply { text = "$cur%"; textSize = 18f; gravity = Gravity.CENTER }
        val bar = SeekBar(this).apply { max = 85; progress = cur - 15 }
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { label.text = "${p + 15}%" }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24), dp(16), dp(24), 0); addView(label); addView(bar) }
        AlertDialog.Builder(this).setTitle("Idle Opacity").setView(box)
            .setPositiveButton("Done") { _, _ -> Store.putInt(this, "opacity", bar.progress + 15); render() }
            .setNegativeButton("Cancel", null).show()
    }

    private fun numberDialog(title: String, key: String, def: Int) {
        val et = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText(Store.getInt(this@MainActivity, key, def).toString()); setSelectAllOnFocus(true) }
        val box = FrameLayout(this).apply { setPadding(dp(24), dp(12), dp(24), 0); addView(et) }
        AlertDialog.Builder(this).setTitle(title).setView(box)
            .setPositiveButton("Done") { _, _ -> Store.putInt(this, key, et.text.toString().toIntOrNull()?.coerceIn(0, 100000) ?: def); render() }
            .setNegativeButton("Cancel", null).show()
    }
}
