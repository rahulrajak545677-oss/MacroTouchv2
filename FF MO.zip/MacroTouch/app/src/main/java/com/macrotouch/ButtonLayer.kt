package com.macrotouch

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Point
import android.os.Handler
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE

/**
 * Overlay position manager for the red touch buttons.
 *
 * It is deliberately separate from the gesture engine (Player):
 *  - Every position here is a VIEW position (where a red ring is drawn). It lives only in this class
 *    and in its own "bp_*" / "ic_*" preference keys.
 *  - Gesture coordinates live only in Macro.strokes. This class only READS them once, to pick a default
 *    place for a button, and never writes them. Dragging or collapsing buttons cannot change a macro.
 *  - Player never reads anything from here, so playing a macro does not move any button or the icon.
 *
 * Expanded: one red button per saved macro (at that macro's first touch point by default). Tap = play it.
 * Collapsed: all buttons fold into ONE red ring that stays where it is and lets touches pass through.
 */
class ButtonLayer(
    private val ctx: Context,
    private val wm: WindowManager,
    private val h: Handler,
    private val screen: () -> Point,
    private val newParams: (Int, Int, Int) -> WindowManager.LayoutParams,
    private val onTap: (String) -> Unit,
    /** Collapsed ring "assist": the user swiped (dx,dy from first touch) starting on the ring at (cx,cy). */
    private val onAssistSwipe: (Float, Float, Float, Float) -> Unit,
    /** Collapsed ring "assist": the user only tapped the ring at (cx,cy). */
    private val onAssistTap: (Float, Float) -> Unit
) {
    class RingView(c: Context) : View(c) {
        private val d = c.resources.displayMetrics.density
        private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF2D3A.toInt(); style = Paint.Style.STROKE; strokeWidth = 5 * d }
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x55FF2D3A }
        private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF2D3A.toInt() }
        override fun onDraw(c: Canvas) {
            val cx = width / 2f; val cy = height / 2f; val r = minOf(width, height) / 2f - 3 * d
            c.drawCircle(cx, cy, r, fill); c.drawCircle(cx, cy, r, ring); c.drawCircle(cx, cy, r * 0.16f, dot)
        }
    }

    private class Btn(val name: String, var x: Float, var y: Float, val view: RingView, val p: WindowManager.LayoutParams)

    private val d = ctx.resources.displayMetrics.density
    private val size = (60 * d).toInt()
    private val btns = mutableListOf<Btn>()
    private var icon: RingView? = null
    private var iconP: WindowManager.LayoutParams? = null
    private var iconX = 0f
    private var iconY = 0f
    private var animator: ValueAnimator? = null
    private var passThrough = false
    var collapsed = Store.getBool(ctx, "collapsed", false); private set
    val hasButtons get() = btns.isNotEmpty()
    /** Human-readable state shown in the app, so a missing button is never a silent failure. */
    var status = "not built yet"; private set

    private fun land(sz: Point) = if (sz.x > sz.y) "l" else "p"
    private fun key(prefix: String, sz: Point, name: String = "") = "${prefix}_${land(sz)}_$name"

    private fun readXY(k: String): Pair<Float, Float>? {
        val v = Store.getStr(ctx, k, "")
        val a = v.split(","); if (a.size != 2) return null
        val x = a[0].toFloatOrNull(); val y = a[1].toFloatOrNull()
        return if (x != null && y != null) x to y else null
    }

    private fun place(p: WindowManager.LayoutParams, x: Float, y: Float) {
        p.gravity = Gravity.TOP or Gravity.START
        p.x = (x - size / 2f).toInt(); p.y = (y - size / 2f).toInt()
    }

    private fun assistOn() = Store.getBool(ctx, "assist_on", true)

    private fun safeRemove(v: View?) { try { if (v != null) wm.removeView(v) } catch (_: Exception) {} }
    private fun safeUpdate(v: View, p: WindowManager.LayoutParams) { try { wm.updateViewLayout(v, p) } catch (_: Exception) {} }

    /** Rebuild from the saved macros. Does not change any macro or any saved button position. */
    fun refresh() {
        clear()
        val sz = screen()
        val macros = Store.load(ctx)
        Diag.i("buttons: refresh screen=${sz.x}x${sz.y} (${land(sz)}) macros=${macros.size} collapsed=$collapsed")
        var other = 0
        for (m in macros) {
            val f = m.strokes.firstOrNull()?.pts?.firstOrNull()
            if (f == null) { Diag.w("buttons: macro \"${m.name}\" has no touch points, no button"); continue }
            val mismatch = m.sw > 0 && m.sh > 0 && (m.sw > m.sh) != (sz.x > sz.y)
            // Other orientation: never hide it silently. The ring is drawn dimmed at the proportional spot; the
            // macro itself is untouched, and playing it still refuses with a clear message.
            val sx = if (m.sw > 0 && m.sh > 0) (if (mismatch) sz.x / m.sh.toFloat() else sz.x / m.sw.toFloat()) else 1f
            val sy = if (m.sw > 0 && m.sh > 0) (if (mismatch) sz.y / m.sw.toFloat() else sz.y / m.sh.toFloat()) else 1f
            val (fx, fy) = if (mismatch) f.y to f.x else f.x to f.y
            val saved = readXY(key("bp", sz, m.name))
            val pos = saved ?: (fx * sx to fy * sy)
            if (mismatch) other++
            Diag.i("buttons: \"${m.name}\" view=(${pos.first.toInt()},${pos.second.toInt()}) ${if (saved != null) "saved" else "default"} recorded=${m.sw}x${m.sh}${if (mismatch) " OTHER ORIENTATION (dimmed)" else ""}")
            val v = RingView(ctx)
            if (mismatch) v.alpha = 0.45f
            val p = newParams(size, size, 0); place(p, pos.first, pos.second)
            val b = Btn(m.name, pos.first, pos.second, v, p)
            attachTouch(b)
            btns.add(b)
        }
        status = when {
            btns.isEmpty() -> "none — no saved gestures"
            other > 0 -> "${btns.size} shown ($other recorded in the other orientation, dimmed)"
            else -> "${btns.size} shown"
        }
        if (collapsed && btns.isNotEmpty()) showIcon() else { collapsed = collapsed && btns.isNotEmpty(); btns.forEach { add(it) } }
        Diag.i("buttons: $status; mode=${if (collapsed) "collapsed" else "expanded"}")
    }

    /** Called on every foreground-app change: confirms the rings are still attached, and re-adds them if not. */
    fun audit(pkg: String) {
        val expected = if (collapsed) listOfNotNull(icon) else btns.map { it.view }
        val detached = expected.count { !it.isAttachedToWindow }
        Diag.i("buttons: audit after foreground=$pkg expected=${expected.size} detached=$detached collapsed=$collapsed passThrough=$passThrough")
        if (detached > 0) { Diag.e("buttons: $detached overlay view(s) were detached when $pkg came to the front — rebuilding"); refresh() }
    }

    private fun add(b: Btn) {
        b.p.flags = if (passThrough) b.p.flags or FLAG_NOT_TOUCHABLE else b.p.flags and FLAG_NOT_TOUCHABLE.inv()
        try {
            wm.addView(b.view, b.p)
            Diag.i("buttons: addView OK \"${b.name}\" type=${b.p.type} flags=0x${Integer.toHexString(b.p.flags)} xy=(${b.p.x},${b.p.y}) size=${b.p.width}")
        } catch (e: Exception) { Diag.e("buttons: addView FAILED for \"${b.name}\" type=${b.p.type}", e); status = "addView failed: ${e.javaClass.simpleName}" }
    }

    private fun attachTouch(b: Btn) {
        var dx = 0f; var dy = 0f; var ox = 0f; var oy = 0f; var drag = false
        b.view.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; ox = b.x; oy = b.y; drag = false }
                MotionEvent.ACTION_MOVE -> {
                    if (!drag && Math.hypot((e.rawX - dx).toDouble(), (e.rawY - dy).toDouble()) > 10 * d) drag = true
                    if (drag) { b.x = ox + e.rawX - dx; b.y = oy + e.rawY - dy; place(b.p, b.x, b.y); safeUpdate(b.view, b.p) }
                }
                MotionEvent.ACTION_UP -> {
                    if (drag) Store.putStr(ctx, key("bp", screen(), b.name), "${b.x},${b.y}")   // view position only
                    else onTap(b.name)
                }
            }
            true
        }
    }

    /** While a macro runs the rings must not catch the injected touches that land on them. */
    fun setPassThrough(on: Boolean) {
        passThrough = on
        if (collapsed) {
            val v = icon; val p = iconP
            if (v != null && p != null) {
                p.flags = if (on || !assistOn()) p.flags or FLAG_NOT_TOUCHABLE else p.flags and FLAG_NOT_TOUCHABLE.inv()
                safeUpdate(v, p)
            }
            return
        }
        for (b in btns) {
            b.p.flags = if (on) b.p.flags or FLAG_NOT_TOUCHABLE else b.p.flags and FLAG_NOT_TOUCHABLE.inv()
            safeUpdate(b.view, b.p)
        }
    }

    fun toggle() { Diag.i("buttons: toggle (was ${if (collapsed) "collapsed" else "expanded"})"); if (collapsed) expand() else collapse() }

    fun collapse() {
        if (collapsed || btns.isEmpty()) return
        val sz = screen()
        val first = btns[0]
        val ix = first.x; val iy = first.y            // the icon stays exactly here until expanded
        collapsed = true
        Store.putBool(ctx, "collapsed", true)
        Store.putStr(ctx, key("ic", sz), "$ix,$iy")
        animateTo(ix, iy, false) { btns.forEach { safeRemove(it.view) }; showIcon() }
    }

    fun expand() {
        if (!collapsed) return
        collapsed = false
        Store.putBool(ctx, "collapsed", false)
        val sz = screen()
        val ic = readXY(key("ic", sz)) ?: (btns.firstOrNull()?.let { it.x to it.y } ?: (0f to 0f))
        safeRemove(icon); icon = null; iconP = null
        for (b in btns) { place(b.p, ic.first, ic.second); add(b) }
        animateTo(ic.first, ic.second, true) {}
    }

    /** Animate window positions only; Btn.x / Btn.y (the remembered original spots) are never touched. */
    private fun animateTo(tx: Float, ty: Float, outward: Boolean, done: () -> Unit) {
        animator?.cancel()
        val from = btns.map { it.x to it.y }
        val a = ValueAnimator.ofFloat(0f, 1f).apply { duration = 200 }
        a.addUpdateListener { va ->
            val f = va.animatedValue as Float
            val g = if (outward) 1f - f else f      // outward: icon spot -> original; inward: original -> icon spot
            btns.forEachIndexed { i, b ->
                val (ox, oy) = from[i]
                place(b.p, ox + (tx - ox) * g, oy + (ty - oy) * g)
                safeUpdate(b.view, b.p)
            }
        }
        a.addListener(object : android.animation.AnimatorListenerAdapter() {
            override fun onAnimationEnd(an: android.animation.Animator) {
                if (outward) btns.forEach { place(it.p, it.x, it.y); safeUpdate(it.view, it.p) }
                done()
            }
        })
        animator = a; a.start()
    }

    private fun showIcon() {
        val sz = screen()
        val pos = readXY(key("ic", sz)) ?: (btns[0].x to btns[0].y)
        iconX = pos.first; iconY = pos.second            // fixed for the whole time the ring is collapsed
        val assist = assistOn()
        val v = RingView(ctx)
        val p = newParams(size, size, if (assist && !passThrough) 0 else FLAG_NOT_TOUCHABLE)
        place(p, iconX, iconY)
        if (assist) {
            // Reads the user's own swipe that starts on the ring. The ring never moves.
            var dx0 = 0f; var dy0 = 0f; var fired = false
            v.setOnTouchListener { _, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { dx0 = e.rawX; dy0 = e.rawY; fired = false }
                    MotionEvent.ACTION_MOVE -> if (!fired) {
                        val dx = e.rawX - dx0; val dy = e.rawY - dy0
                        if (Math.hypot(dx.toDouble(), dy.toDouble()) >= 28 * d) {
                            fired = true
                            Diag.i("assist: swipe read dx=${dx.toInt()} dy=${dy.toInt()} from ring (${iconX.toInt()},${iconY.toInt()})")
                            onAssistSwipe(dx, dy, iconX, iconY)
                        }
                    }
                    MotionEvent.ACTION_UP -> if (!fired && Math.hypot((e.rawX - dx0).toDouble(), (e.rawY - dy0).toDouble()) < 10 * d) {
                        Diag.i("assist: tap on ring")
                        onAssistTap(iconX, iconY)
                    }
                }
                true
            }
        }
        try {
            wm.addView(v, p)
            Diag.i("buttons: collapsed icon addView OK type=${p.type} flags=0x${Integer.toHexString(p.flags)} xy=(${p.x},${p.y}) assist=$assist")
        } catch (e: Exception) { Diag.e("buttons: collapsed icon addView FAILED type=${p.type}", e); status = "addView failed: ${e.javaClass.simpleName}" }
        icon = v; iconP = p
    }

    private fun clear() {
        animator?.cancel(); animator = null
        btns.forEach { safeRemove(it.view) }; btns.clear()
        safeRemove(icon); icon = null; iconP = null
    }

    fun hide() { Diag.i("buttons: hide"); status = "hidden"; clear() }
}
