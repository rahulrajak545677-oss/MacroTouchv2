# Macro Touch (Android)

AssistiveTouch-style floating button + gesture recorder/player for Android.

## Build the APK (no PC needed)
1. Create a GitHub repo, upload this whole folder (keep `.github/workflows/build.yml`).
2. Repo → Actions → "Build APK" → Run workflow.
3. Download artifact `MacroTouch-APK`, unzip, install `app-debug.apk`.

(Or open the folder in Android Studio → Run.)

## First run
1. Open Macro Touch → switch **AssistiveTouch** on → enable the accessibility service "Macro Touch".
   Android 13+: Settings → Apps → Macro Touch → ⋮ → *Allow restricted settings*, then enable it.
2. A floating button appears. Tap it → **Custom → +** (or "Create New Gesture…" in the app).
3. Tap/swipe (multi-finger OK) → **Save** → type a name.
4. Go to your game/app → tap button → Custom → your gesture. Tap the button again to stop. Repeat count/delay: app → Playback.

## Playback engine (v2)
- Touches that overlap in time are sent as one multi-finger gesture; actions run one after another.
- Actions longer than 600 ms are sent in 200 ms pieces (willContinue/continueStroke), so Stop/Pause work between pieces.
- Red circles are drawn from the strokes actually handed to `dispatchGesture()`.
- While a macro runs: **tap the button = stop**, **long-press = pause/resume** (pause happens between actions).
- Per-macro speed, repeat and delay: Custom Gestures → tap a macro.
- Limits: max simultaneous touches = `GestureDescription.getMaxStrokeCount()` (device dependent); a physical touch cancels the injected gesture; macros recorded in portrait won't play in landscape (and vice versa); apps may ignore injected touches (e.g. secure screens, some anti-cheat).

## Device test checklist (not yet run on hardware)
1. Service enable flow incl. Android 13+ "Allow restricted settings".
2. Gestures menu: Long Press, Double Tap, Hold and Drag, Pinch In/Out, Rotate, Pinch and Rotate, Swipe ×4 — circles appear where the touch lands, move, vanish.
3. Record a 2–3 finger macro → Save → Play; compare with the recording.
4. Tap button mid-macro → fingers lift within ~0.6 s; no stuck touch.
5. Long-press button mid-macro → pauses after current action; long-press again resumes.
6. Rotate the phone: button stays on screen; mismatched-orientation macro shows a message.
7. Rename/delete a macro assigned to Single-Tap: button still opens the menu.
