package com.macrotouch

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Point
import android.os.Handler
import android.os.SystemClock
import java.util.IdentityHashMap

/**
 * Macro playback engine. Everything runs on the main thread.
 *
 * - Strokes that overlap in time are grouped into a "cluster" and dispatched as ONE gesture
 *   (simultaneous fingers). Clusters run one after another, never overlapping, because a new
 *   dispatchGesture() cancels the gesture in progress.
 * - Clusters longer than SINGLE_MAX_MS are dispatched in CHUNK_MS pieces chained with
 *   willContinue / continueStroke, so Stop and Pause can take effect between pieces and the
 *   finger's speed profile (holds, slow/fast drags) is kept.
 * - [live] holds the strokes that were actually handed to dispatchGesture, with absolute uptime
 *   timestamps. The red-circle overlay draws from it, so circles follow what was dispatched.
 */
class Player(
    private val svc: AccessibilityService,
    private val h: Handler,
    private val screen: () -> Point
) {
    companion object {
        const val CHUNK_MS = 200L
        const val SINGLE_MAX_MS = 600L
        private const val MIN_DUR = 30L

        fun effEnd(s: Stroke) = maxOf(s.end, s.start + MIN_DUR)

        /** Returns the clusters and how many strokes were dropped for exceeding getMaxStrokeCount(). */
        fun buildClusters(strokes: List<Stroke>, maxStrokes: Int): Pair<List<List<Stroke>>, Int> {
            val out = mutableListOf<MutableList<Stroke>>()
            var curEnd = -1L
            var dropped = 0
            for (s in strokes.sortedBy { it.start }) {
                val cur = out.lastOrNull()
                if (cur != null && s.start < curEnd + 5) {
                    if (cur.size < maxStrokes) { cur.add(s); curEnd = maxOf(curEnd, effEnd(s)) } else dropped++
                } else { out.add(mutableListOf(s)); curEnd = effEnd(s) }
            }
            return out to dropped
        }
    }

    val live = mutableListOf<Stroke>()
    var running = false; private set
    var paused = false; private set
    var onFinished: (() -> Unit)? = null
    var onPausedReached: (() -> Unit)? = null
    var onMessage: ((String) -> Unit)? = null

    private class Active(val desc: GestureDescription.StrokeDescription, val x: Float, val y: Float)

    private var gen = 0
    private var clusters: List<List<Stroke>> = emptyList()
    private var loops = 0
    private var gapMs = 0L
    private var loopNo = 1
    private var idx = 0
    private var loopT0 = 0L
    private var pauseT0 = 0L
    private var pendingNext = false
    private var inFlight = false
    private var stopRequested = false
    private val active = IdentityHashMap<Stroke, Active>()
    private var scr = Point(1, 1)

    fun start(m: Macro, loops: Int, gapMs: Long, speed: Float): Boolean {
        if (running) finishRun()
        if (m.strokes.isEmpty()) return false
        val sz = screen()
        var sx = 1f; var sy = 1f
        if (m.sw > 0 && m.sh > 0) {
            if ((m.sw > m.sh) != (sz.x > sz.y)) {
                onMessage?.invoke("“${m.name}” was recorded in the other screen orientation. Rotate the phone and try again.")
                return false
            }
            sx = sz.x / m.sw.toFloat(); sy = sz.y / m.sh.toFloat()
        }
        val k = if (speed > 0f) speed else 1f
        val scaled = m.strokes.map { s -> Stroke(s.pts.map { Pt(it.x * sx, it.y * sy, (it.t / k).toLong()) }) }
        val (cl, dropped) = buildClusters(scaled, GestureDescription.getMaxStrokeCount())
        if (dropped > 0) onMessage?.invoke("This device allows ${GestureDescription.getMaxStrokeCount()} simultaneous touches; $dropped extra touch(es) will be skipped.")
        scr = sz; clusters = cl
        this.loops = loops; this.gapMs = gapMs; loopNo = 1
        running = true; paused = false; stopRequested = false; pendingNext = false; inFlight = false
        gen++
        active.clear(); live.clear()
        beginLoop()
        return true
    }

    /** Pause takes effect between actions (never mid-gesture, so no finger is left pressed). */
    fun pause() { if (running && !paused) paused = true }

    fun resume() {
        if (!running || !paused) return
        paused = false
        if (pendingNext) {
            loopT0 += SystemClock.uptimeMillis() - pauseT0
            pendingNext = false
            next()
        }
    }

    /** Stops after the piece that is currently being injected finishes (<= ~600 ms), releasing every finger. */
    fun stop() {
        if (!running) return
        if (inFlight) {
            stopRequested = true
            val g = gen
            h.postDelayed({ if (g == gen && running) finishRun() }, 1500)
        } else finishRun()
    }

    private fun finishRun() {
        val was = running
        running = false; paused = false; stopRequested = false; pendingNext = false; inFlight = false
        gen++
        active.clear(); live.clear()
        if (was) onFinished?.invoke()
    }

    private fun fail(msg: String) { onMessage?.invoke(msg); finishRun() }

    private fun beginLoop() { idx = 0; loopT0 = SystemClock.uptimeMillis(); next() }

    private fun reachPause() { pendingNext = true; pauseT0 = SystemClock.uptimeMillis(); onPausedReached?.invoke() }

    private fun next() {
        if (!running || stopRequested) return
        if (paused) { reachPause(); return }
        if (idx >= clusters.size) { endOfLoop(); return }
        val c = clusters[idx]
        val wait = (c[0].start - (SystemClock.uptimeMillis() - loopT0)).coerceAtLeast(0L)
        val g = gen
        h.postDelayed({
            if (g != gen || !running || stopRequested) return@postDelayed
            if (paused) reachPause() else runCluster(c)
        }, wait)
    }

    private fun endOfLoop() {
        if (loops != 0 && loopNo >= loops) { finishRun(); return }
        loopNo++
        val g = gen
        h.postDelayed({ if (g == gen && running && !stopRequested) beginLoop() }, gapMs)
    }

    private fun runCluster(c: List<Stroke>) {
        val base = c[0].start
        val total = c.maxOf { effEnd(it) } - base
        active.clear()
        chunkAt(c, base, total, 0L, SystemClock.uptimeMillis())
    }

    private fun chunkAt(c: List<Stroke>, base: Long, total: Long, a: Long, wall0: Long) {
        if (!running) return
        val len = if (total <= SINGLE_MAX_MS) total else CHUNK_MS
        val b = a + len
        val now = SystemClock.uptimeMillis()
        // If earlier pieces ran late, squeeze this piece a little so the macro catches up instead of drifting.
        val lag = (now - wall0) - a
        val scale = if (lag > 0 && len > 0) maxOf(0.4f, (len - lag).toFloat() / len) else 1f

        live.removeAll { it.end + 600 < now }
        val gb = GestureDescription.Builder()
        val nextActive = IdentityHashMap<Stroke, Active>()
        var added = 0
        for (s in c) {
            val rs = s.start - base; val re = effEnd(s) - base
            if (re <= a || rs >= b) continue
            val seg0 = maxOf(rs, a); val seg1 = minOf(re, b)
            val pts = segPoints(s, seg0 + base, seg1 + base)
            val path = pathOf(pts)
            val off = ((seg0 - a) * scale).toLong()
            val dur = maxOf(1L, ((seg1 - seg0) * scale).toLong())
            val cont = re > b
            val prev = active[s]
            val d = try {
                if (prev != null) prev.desc.continueStroke(path, off, dur, cont)
                else GestureDescription.StrokeDescription(path, off, dur, cont)
            } catch (e: Exception) { fail("Could not build gesture: ${e.message}"); return }
            gb.addStroke(d); added++
            if (cont) nextActive[s] = Active(d, pts.last().x, pts.last().y)
            live.add(Stroke(pts.map { Pt(it.x, it.y, now + ((it.t - base - a) * scale).toLong()) }))
        }
        active.clear(); active.putAll(nextActive)
        if (added == 0) { idx++; next(); return }

        val more = b < total
        val g = gen
        inFlight = true
        val cb = object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gd: GestureDescription?) {
                if (g != gen) return
                inFlight = false
                if (stopRequested) { release(); return }
                if (!running) return
                if (more) chunkAt(c, base, total, b, wall0) else { active.clear(); idx++; next() }
            }
            override fun onCancelled(gd: GestureDescription?) {
                if (g != gen) return
                inFlight = false
                active.clear()
                if (!stopRequested) onMessage?.invoke("Android cancelled the gesture (another touch or app interrupted it).")
                finishRun()
            }
        }
        val ok = try { svc.dispatchGesture(gb.build(), cb, h) } catch (e: Exception) { false }
        if (!ok) { inFlight = false; fail("Android rejected the gesture. Is the accessibility service still enabled?") }
    }

    /** Lift every finger that is still held down by a continued stroke, then finish. */
    private fun release() {
        if (active.isEmpty()) { finishRun(); return }
        val g = gen
        try {
            val gb = GestureDescription.Builder()
            for (a in active.values) {
                val p = Path(); p.moveTo(a.x, a.y)
                gb.addStroke(a.desc.continueStroke(p, 0L, 1L, false))
            }
            active.clear()
            val cb = object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gd: GestureDescription?) { if (g == gen) finishRun() }
                override fun onCancelled(gd: GestureDescription?) { if (g == gen) finishRun() }
            }
            if (!svc.dispatchGesture(gb.build(), cb, h)) finishRun()
        } catch (e: Exception) { finishRun() }
    }

    private fun interp(s: Stroke, t: Long): Pair<Float, Float> {
        val p = s.pts
        if (t <= p[0].t) return p[0].x to p[0].y
        for (i in 1 until p.size) {
            val b = p[i]
            if (t <= b.t) {
                val a = p[i - 1]
                val f = if (b.t == a.t) 1f else (t - a.t).toFloat() / (b.t - a.t)
                return (a.x + (b.x - a.x) * f) to (a.y + (b.y - a.y) * f)
            }
        }
        return p.last().x to p.last().y
    }

    /** The part of stroke [s] between macro times t0..t1, clamped to the screen. */
    private fun segPoints(s: Stroke, t0: Long, t1: Long): List<Pt> {
        val mw = scr.x - 1f; val mh = scr.y - 1f
        val out = ArrayList<Pt>()
        fun add(x: Float, y: Float, t: Long) { out.add(Pt(x.coerceIn(0f, mw), y.coerceIn(0f, mh), t)) }
        val a = interp(s, t0); add(a.first, a.second, t0)
        for (p in s.pts) if (p.t > t0 && p.t < t1) add(p.x, p.y, p.t)
        val e = interp(s, t1); add(e.first, e.second, t1)
        return out
    }

    private fun pathOf(pts: List<Pt>): Path {
        val p = Path(); val f = pts[0]
        p.moveTo(f.x, f.y)
        val moved = pts.any { Math.abs(it.x - f.x) > 0.5f || Math.abs(it.y - f.y) > 0.5f }
        if (moved) for (i in 1 until pts.size) p.lineTo(pts[i].x, pts[i].y)
        return p
    }
}
