package com.macrotouch

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.content.res.Configuration
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.provider.Settings
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.*
import android.view.WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
import android.view.WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
import android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
import android.view.WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
import android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
import android.view.WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
import android.view.accessibility.AccessibilityEvent
import android.widget.*

class TouchService : AccessibilityService() {

    companion object { @Volatile var inst: TouchService? = null }

    private class Item(val sym: String, val label: String, val act: () -> Unit)

    private lateinit var wm: WindowManager
    private val h = Handler(Looper.getMainLooper())
    private var button: View? = null
    private var bp: WindowManager.LayoutParams? = null
    private var menu: FrameLayout? = null
    private var recorder: RecorderView? = null
    private var viz: VizView? = null
    private var picker: View? = null
    private lateinit var player: Player
    private var layer: ButtonLayer? = null
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val dm get() = resources.displayMetrics
    private fun dp(v: Int) = (v * dm.density).toInt()

    override fun onServiceConnected() {
        inst = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        Diag.i("service connected: sdk=${Build.VERSION.SDK_INT} overlayType=TYPE_ACCESSIBILITY_OVERLAY(${TYPE_ACCESSIBILITY_OVERLAY}) canDrawOverlays=${Settings.canDrawOverlays(this)}")
        player = Player(this, h) { realSize() }
        player.onFinished = { removeViz(); layer?.setPassThrough(false); if (button != null) dim() }
        player.onPausedReached = { toast("Paused — long-press the floating button to resume") }
        player.onMessage = { toast(it) }
        if (Store.getBool(this, "enabled", false)) showButton()
    }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        val ev = e ?: return
        if (ev.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = ev.packageName?.toString() ?: return
        if (pkg == packageName || pkg.startsWith("com.android.systemui")) return
        layer?.audit(pkg)          // log + self-check that the overlays survived the app switch
    }
    override fun onInterrupt() { Diag.w("onInterrupt"); stopPlayback() }

    /** Adds an overlay window and reports exactly why it failed instead of swallowing the error. */
    private fun addOv(what: String, v: View, p: WindowManager.LayoutParams): Boolean = try {
        wm.addView(v, p)
        Diag.i("overlay: $what addView OK type=${p.type} flags=0x${Integer.toHexString(p.flags)} xy=(${p.x},${p.y}) size=${p.width}x${p.height}")
        true
    } catch (e: WindowManager.BadTokenException) {
        Diag.e("overlay: $what BadTokenException (type=${p.type}) — window type/token not allowed", e); toast("Overlay failed: BadTokenException"); false
    } catch (e: SecurityException) {
        Diag.e("overlay: $what SecurityException (type=${p.type}) — missing permission", e); toast("Overlay failed: permission"); false
    } catch (e: Exception) {
        Diag.e("overlay: $what FAILED (type=${p.type})", e); toast("Overlay failed: ${e.javaClass.simpleName}"); false
    }

    /** Text for the app's Touch Buttons row. */
    fun buttonStatus(): String = when {
        !Store.getBool(this, "buttons_on", false) -> "Off"
        button == null -> "On · floating button is off"
        else -> "On · " + (layer?.status ?: "starting")
    }
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val b = button ?: return
        val p = bp ?: return
        h.post {
            refreshButtons()
            val sz = realSize(); val size = dp(58)
            p.x = p.x.coerceIn(0, maxOf(0, sz.x - size)); p.y = p.y.coerceIn(0, maxOf(0, sz.y - size))
            try { wm.updateViewLayout(b, p) } catch (_: Exception) {}
        }
    }
    override fun onUnbind(intent: Intent?): Boolean {
        stopPlayback(); closeMenu(); removeRecorder(); hideButton(); inst = null
        return super.onUnbind(intent)
    }

    private fun lp(w: Int, hh: Int, extra: Int = 0, focusable: Boolean = false): WindowManager.LayoutParams {
        val f = FLAG_LAYOUT_IN_SCREEN or FLAG_LAYOUT_NO_LIMITS or extra or (if (focusable) 0 else FLAG_NOT_FOCUSABLE)
        val p = WindowManager.LayoutParams(w, hh, TYPE_ACCESSIBILITY_OVERLAY, f, PixelFormat.TRANSLUCENT)
        if (Build.VERSION.SDK_INT >= 28) p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        return p
    }
    private fun realSize(): Point {
        val m = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(m)
        return Point(m.widthPixels, m.heightPixels)
    }
    private fun safeRemove(v: View?) { try { if (v != null) wm.removeView(v) } catch (_: Exception) {} }

    // ───────────── floating button ─────────────
    private class BtnView(c: android.content.Context) : View(c) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(cv: Canvas) {
            val w = width.toFloat()
            p.color = 0xE63A3A3C.toInt(); cv.drawRoundRect(0f, 0f, w, w, w * 0.28f, w * 0.28f, p)
            p.color = 0x99FFFFFF.toInt(); cv.drawCircle(w / 2, w / 2, w * 0.34f, p)
            p.color = 0xFFFFFFFF.toInt(); cv.drawCircle(w / 2, w / 2, w * 0.26f, p)
        }
    }

    private val dimR = Runnable { button?.alpha = Store.getInt(this, "opacity", 37) / 100f }
    private fun wake() { h.removeCallbacks(dimR); button?.alpha = 1f }
    private fun dim() { h.removeCallbacks(dimR); h.postDelayed(dimR, 3000) }

    fun showButton() {
        if (button != null) return
        val size = dp(58)
        val v = BtnView(this)
        val sz0 = realSize()
        val p = lp(size, size).apply {
            gravity = Gravity.TOP or Gravity.START
            x = Store.getInt(this@TouchService, "bx", sz0.x - size - dp(6)).coerceIn(0, maxOf(0, sz0.x - size))
            y = Store.getInt(this@TouchService, "by", sz0.y / 2).coerceIn(0, maxOf(0, sz0.y - size))
        }
        var dx = 0f; var dy = 0f; var ox = 0; var oy = 0; var drag = false
        var wasRunning = false; var longHandled = false
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean { if (!wasRunning) runAction("a_single"); return true }
            override fun onDoubleTap(e: MotionEvent): Boolean { if (!wasRunning || Store.getStr(this@TouchService, "a_double", "toggle") == "toggle") runAction("a_double"); return true }
            override fun onLongPress(e: MotionEvent) {
                if (drag) return
                if (wasRunning) { if (player.running) { longHandled = true; togglePause() } } else runAction("a_long")
            }
        })
        v.setOnTouchListener { _, e ->
            wake()
            if (e.actionMasked == MotionEvent.ACTION_DOWN) { wasRunning = player.running; longHandled = false }
            gd.onTouchEvent(e)
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; ox = p.x; oy = p.y; drag = false }
                MotionEvent.ACTION_MOVE -> {
                    if (!drag && Math.hypot((e.rawX - dx).toDouble(), (e.rawY - dy).toDouble()) > dp(8)) drag = true
                    if (drag) {
                        p.x = (ox + e.rawX - dx).toInt(); p.y = (oy + e.rawY - dy).toInt()
                        try { wm.updateViewLayout(v, p) } catch (_: Exception) {}
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    // While a macro runs: tap = stop immediately, long-press = pause / resume.
                    if (e.actionMasked == MotionEvent.ACTION_UP && wasRunning && !drag && !longHandled && player.running) {
                        stopPlayback(); toast("Stopped")
                    }
                    if (drag) {
                        val sw = realSize().x
                        p.x = if (p.x + size / 2 < sw / 2) dp(6) else sw - size - dp(6)
                        try { wm.updateViewLayout(v, p) } catch (_: Exception) {}
                        Store.putInt(this, "bx", p.x); Store.putInt(this, "by", p.y)
                    }
                    dim()
                }
            }
            true
        }
        if (!addOv("floating button", v, p)) return
        button = v; bp = p
        dim()
        refreshButtons()
    }

    fun hideButton() { h.removeCallbacks(dimR); safeRemove(button); button = null; layer?.hide() }

    /** Show / rebuild / hide the red touch buttons according to the app setting. Never touches macros. */
    fun refreshButtons() {
        if (!::wm.isInitialized) return
        if (button == null || !Store.getBool(this, "buttons_on", false)) {
            Diag.i("refreshButtons: not showing (floatingButton=${button != null}, touchButtons=${Store.getBool(this, "buttons_on", false)})")
            layer?.hide(); return
        }
        val l = layer ?: ButtonLayer(this, wm, h, { realSize() }, { w, hh, extra -> lp(w, hh, extra) }) { name ->
            Store.load(this).firstOrNull { it.name == name }?.let { play(it) }
        }.also { layer = it }
        l.refresh()
    }

    private fun toggleButtons() {
        if (!Store.getBool(this, "buttons_on", false)) { toast("Turn on “Touch Buttons” in the FF app first"); return }
        val l = layer
        if (l == null || !l.hasButtons) { toast("No saved gestures to show as buttons"); return }
        l.toggle()
    }

    private fun runAction(key: String) {
        val def = if (key == "a_single") "menu" else if (key == "a_double") "toggle" else "none"
        val a = Store.getStr(this, key, def)
        when {
            a == "menu" -> showMenu()
            a == "toggle" -> toggleButtons()
            a.startsWith("m:") -> {
                val m = Store.load(this).firstOrNull { it.name == a.substring(2) }
                if (m != null) play(m)
                else if (key == "a_single") showMenu()   // never leave the user with a dead button
                else toast("Gesture “${a.substring(2)}” not found")
            }
        }
    }

    private fun togglePause() {
        if (player.paused) { player.resume(); toast("Resumed") }
        else { player.pause(); toast("Pausing after the current action…") }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ───────────── menu ─────────────
    private fun g(action: Int) { closeMenu(); h.postDelayed({ performGlobalAction(action) }, 180) }

    private fun showMenu(page: String = "top") {
        closeMenu()
        val items: List<Item?> = when (page) {
            "custom" -> listOf<Item?>(Item("←", "Back") { showMenu() }) +
                Store.load(this).map { m -> Item("★", m.name) { closeMenu(); play(m) } } +
                Item("+", "New") { startRecorder() }
            "gestures" -> listOf<Item?>(
                Item("←", "Back") { showMenu() },
                Item("◉", "Long Press") { pick("Long Press") },
                Item("◎", "Double Tap") { pick("Double Tap") },
                Item("⇢", "Hold and Drag") { pick("Hold and Drag") },
                Item("⤡", "Pinch In") { pick("Pinch In") },
                Item("⤢", "Pinch Out") { pick("Pinch Out") },
                Item("↻", "Rotate") { pick("Rotate") },
                Item("⤢", "Pinch and Rotate") { pick("Pinch and Rotate") },
                Item("↑", "Swipe Up") { closeMenu(); h.postDelayed({ doGesture("Swipe Up", 0f, 0f) }, 180) },
                Item("↓", "Swipe Down") { closeMenu(); h.postDelayed({ doGesture("Swipe Down", 0f, 0f) }, 180) },
                Item("⇦", "Swipe Left") { closeMenu(); h.postDelayed({ doGesture("Swipe Left", 0f, 0f) }, 180) },
                Item("⇨", "Swipe Right") { closeMenu(); h.postDelayed({ doGesture("Swipe Right", 0f, 0f) }, 180) }
            )
            "device" -> {
                val l = mutableListOf<Item?>(
                    Item("←", "Back") { showMenu() },
                    Item("◁", "Back Button") { g(GLOBAL_ACTION_BACK) },
                    Item("▭", "App Switcher") { g(GLOBAL_ACTION_RECENTS) },
                    Item("⏻", "Power Menu") { g(GLOBAL_ACTION_POWER_DIALOG) }
                )
                if (Build.VERSION.SDK_INT >= 28) {
                    l.add(Item("🔒", "Lock Screen") { g(GLOBAL_ACTION_LOCK_SCREEN) })
                    l.add(Item("📷", "Screenshot") { g(GLOBAL_ACTION_TAKE_SCREENSHOT) })
                }
                l
            }
            else -> listOf(
                null, Item("🔔", "Notification Center") { g(GLOBAL_ACTION_NOTIFICATIONS) }, null,
                Item("★", "Custom") { showMenu("custom") }, null, Item("▯", "Device") { showMenu("device") },
                Item("◎", "Gestures") { showMenu("gestures") }, Item("⌂", "Home") { g(GLOBAL_ACTION_HOME) },
                Item("⚙", "Control Center") { g(GLOBAL_ACTION_QUICK_SETTINGS) }
            )
        }
        val root = FrameLayout(this).apply { setBackgroundColor(0x33000000); setOnClickListener { closeMenu() } }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
            isClickable = true
        }
        items.chunked(3).forEach { rowItems ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (i in 0 until 3) row.addView(tile(rowItems.getOrNull(i)), LinearLayout.LayoutParams(dp(100), dp(92)))
            col.addView(row)
        }
        val panel = ScrollView(this).apply {
            background = GradientDrawable().apply { setColor(0xEE2C2C2E.toInt()); cornerRadius = dp(26).toFloat() }
            addView(col)
        }
        val tall = items.size > 9
        root.addView(panel, FrameLayout.LayoutParams(dp(330), if (tall) (dm.heightPixels * 0.7).toInt() else WRAP, Gravity.CENTER))
        addOv("menu", root, lp(MATCH, MATCH))
        menu = root
    }

    private fun tile(item: Item?): View {
        val t = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        if (item == null) return t
        t.addView(TextView(this).apply { text = item.sym; textSize = 28f; setTextColor(Color.WHITE); gravity = Gravity.CENTER })
        t.addView(TextView(this).apply {
            text = item.label; textSize = 12f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            maxLines = 2; setPadding(dp(4), dp(4), dp(4), 0)
        })
        t.setOnClickListener { item.act() }
        return t
    }

    private fun closeMenu() { safeRemove(menu); menu = null; safeRemove(picker); picker = null }

    // ───────────── built-in gestures ─────────────
    private fun pick(kind: String, first: PointF? = null) {
        closeMenu()
        val prompt = when {
            kind == "Hold and Drag" && first == null -> "Tap where to START the drag:\n$kind"
            first != null -> "Tap where to drag TO"
            else -> "Tap where you want to use:\n$kind"
        }
        val v = FrameLayout(this).apply { setBackgroundColor(0x44000000) }
        v.addView(TextView(this).apply {
            text = prompt; setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER
        }, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.CENTER))
        v.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_DOWN) {
                val x = e.rawX; val y = e.rawY
                safeRemove(picker); picker = null
                if (kind == "Hold and Drag" && first == null) h.postDelayed({ pick(kind, PointF(x, y)) }, 120)
                else h.postDelayed({
                    if (first != null) doGesture(kind, first.x, first.y, x, y) else doGesture(kind, x, y)
                }, 220)
            }
            true
        }
        if (addOv("picker", v, lp(MATCH, MATCH))) picker = v
        h.postDelayed({ if (picker === v) { safeRemove(v); picker = null } }, 20000)   // auto-cancel
    }

    private fun doGesture(kind: String, x: Float, y: Float, x2: Float = 0f, y2: Float = 0f) {
        val sz = realSize(); val k = dp(130).toFloat(); val n = dp(20).toFloat(); val r = dp(100).toFloat()
        val w = sz.x.toFloat(); val hh = sz.y.toFloat()
        val strokes: List<Stroke> = when (kind) {
            "Long Press" -> GestureLib.longPress(x, y)
            "Double Tap" -> GestureLib.doubleTap(x, y)
            "Hold and Drag" -> GestureLib.holdDrag(x, y, x2, y2)
            "Pinch In" -> GestureLib.twoFinger(x, y, k, n, 0f, 450)
            "Pinch Out" -> GestureLib.twoFinger(x, y, n, k, 0f, 450)
            "Rotate" -> GestureLib.twoFinger(x, y, r, r, 90f, 700)
            "Pinch and Rotate" -> GestureLib.twoFinger(x, y, k, n, 90f, 700)
            "Swipe Up" -> GestureLib.swipe(w / 2, hh * 0.72f, w / 2, hh * 0.28f)
            "Swipe Down" -> GestureLib.swipe(w / 2, hh * 0.28f, w / 2, hh * 0.72f)
            "Swipe Left" -> GestureLib.swipe(w * 0.8f, hh / 2, w * 0.2f, hh / 2)
            "Swipe Right" -> GestureLib.swipe(w * 0.2f, hh / 2, w * 0.8f, hh / 2)
            else -> emptyList()
        }
        // Same player + same red circles as recorded macros.
        startPlayback(Macro(kind, strokes, sz.x, sz.y), 1, 0L, 1f, false)
    }

    // ───────────── recorder ─────────────
    fun startRecorder() {
        stopPlayback(); closeMenu(); removeRecorder()
        val list = Store.load(this)
        var n = list.size + 1
        while (list.any { it.name == "Macro$n" }) n++
        val r = RecorderView(this, "Macro$n", { removeRecorder() }) { name, strokes ->
            val l = Store.load(this)
            var nm = name; var k = 2
            while (l.any { it.name == nm }) { nm = "$name $k"; k++ }
            val sz = realSize()
            l.add(Macro(nm, strokes, sz.x, sz.y)); Store.save(this, l)
            removeRecorder(); toast("Saved “$nm”")
        }
        if (addOv("recorder", r, lp(MATCH, MATCH, 0, true).also { it.softInputMode = SOFT_INPUT_ADJUST_PAN })) recorder = r
    }
    private fun removeRecorder() { safeRemove(recorder); recorder = null }

    // ───────────── playback ─────────────
    /** Draws red circles from the strokes the player has really dispatched (Player.live). */
    private class VizView(c: android.content.Context, val live: List<Stroke>) : View(c) {
        private val d = c.resources.displayMetrics.density
        private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF2D3A.toInt(); style = Paint.Style.STROKE; strokeWidth = 5 * d }
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF2D3A.toInt() }
        private val loc = IntArray(2)
        override fun onDraw(c: Canvas) {
            getLocationOnScreen(loc)
            drawTouches(c, live, SystemClock.uptimeMillis(), loc[0].toFloat(), loc[1].toFloat(), 30 * d, ring, fill)
            postInvalidateOnAnimation()
        }
    }

    private fun removeViz() { safeRemove(viz); viz = null }

    fun play(m: Macro) {
        val loops = if (m.loops >= 0) m.loops else Store.getInt(this, "loops", 0)
        val gap = (if (m.gap >= 0) m.gap else Store.getInt(this, "gap", 0)).toLong()
        startPlayback(m, loops, gap, m.speed / 100f, true)
    }

    private fun startPlayback(m: Macro, loops: Int, gap: Long, speed: Float, announce: Boolean) {
        if (m.strokes.isEmpty()) return
        if (!player.start(m, loops, gap, speed)) return
        removeViz()
        layer?.setPassThrough(true)
        // Collapsed icon mode (as in the reference video): only the single ring is shown; it never moves.
        if (layer?.collapsed != true) VizView(this, player.live).also { if (addOv("playback circles", it, lp(MATCH, MATCH, FLAG_NOT_TOUCHABLE))) viz = it }
        if (announce) toast("Playing “${m.name}” — tap the button to stop, long-press to pause")
    }

    fun stopPlayback() {
        if (::player.isInitialized && player.running) player.stop() else removeViz()
        if (button != null) dim()
    }
}
